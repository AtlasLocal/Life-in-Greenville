<?php
/**
 * The sidebar containing the main widget area.
 *
 * @package melinda
 */
?>
