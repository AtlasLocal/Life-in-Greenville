#Melinda - Professional Business Multi-Purpose WordPress Theme#

Powerful flat theme with focus in agency and creative websites, but can be used as shop. Flexible style system with primary colors and font changes avaliable. [View all features](http://melinda.themes.tvda.eu)

###[Get theme](https://themeforest.net/item/melinda-professional-business-multipurpose-wordpress-theme/16084496)###


##Change log##


#### v1.0.6 – 29.09.2016 ####

* FIX: theme options
* FIX: search results


#### v1.0.5 – 20.09.2016 ####

* UPD: plugin Visual Composer
* FIX: full screen title wrapper
* FIX: currency switcher


#### v1.0.4 – 03.09.2016 ####

* ADD: custom HTML option
* ADD: dynamic area options for shop
* ADD: fixed header on mobile
* FIX: blog metro on mobile
* FIX: password in checkout form


#### v1.0.3 – 16.08.2016 ####

* UPD: plugin Ultimate Addons for Visual Composer
* UPD: pot file


#### v1.0.2 – 06.08.2016 ####

* UPD: demo content


#### v1.0.1 – 05.08.2016 ####

* FIX: blog with sidebar
* FIX: one click demo importer
* FIX: preloader
