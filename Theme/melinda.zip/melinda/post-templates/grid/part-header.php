<?php
/**
 * @package melinda
 */
?>

<?php the_title( '<header><h3 class="post-grid_h">', '</h3></header>' ); ?>
