<?php
/**
 * @package melinda
 */
?>

<a href="<?php echo esc_url(get_permalink()); ?>" class="post-grid_lk" rel="bookmark" title="<?php the_title(); ?>"></a>
