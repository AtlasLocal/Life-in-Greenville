<?php
/**
 * @package melinda
 */
?>

<?php the_title( '<header><h3 class="post-masonry_h">', '</h3></header>' ); ?>
