<?php
/**
 * @package melinda
 */
?>

<div class="post-standard_aside">
	<time datetime="<?php echo esc_attr(get_the_date('c')); ?>" class="post-standard_date"><span class="post-standard_date-day"><?php echo esc_html(get_the_date('j')); ?></span><br><span class="post-standard_date-month"><?php echo esc_html(get_the_date('F')); ?></span></time>
</div>
