<?php
/**
 * @package melinda
 */
?>

<?php the_title( sprintf( '<header><h3 class="post-standard_h"><a href="%s" class="post-standard_lk" rel="bookmark">', esc_url(get_permalink()) ), '</a></h3></header>' ); ?>
